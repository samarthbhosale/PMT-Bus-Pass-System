function emailValidation(){
	var email = document.getElementById("email-id").value;
	alert(email);
}

function passwordValidation(){
	var password = document.getElementById("password").value;
	alert(password);
}