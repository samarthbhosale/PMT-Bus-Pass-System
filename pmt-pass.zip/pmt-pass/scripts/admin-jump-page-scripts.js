function goToAdminDashboard(){
	window.location = "admin-dashboard.html";
}
function goToApproveApplicationPage(){
	window.location = "admin-approve-application-page.html";
}
function goToRejectedApplicationPage(){
	window.location = "admin-rejected-application-page.html";
}
function logoutAdmin(){
	window.location = "admin-login-page.html";
}