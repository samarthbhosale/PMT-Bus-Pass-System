Please make ensure that you have servlet-api.jar & jsp-api.jar files in the 
C:/Program File/Java/jdk/jre/lib/ext
folder because without these files you cannot able to run the servlet programs
These files are given in the lib folder in the current folder.